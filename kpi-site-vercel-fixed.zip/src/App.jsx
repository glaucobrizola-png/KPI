import React, { useMemo, useState, useEffect } from "react";
import KPIS from "./kpis.json";
import { Search, Filter, X, Info, Layers, Calculator, Download, Upload } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const CLUSTERS = [
  { id: "Safety", label: "Safety (EHS)" },
  { id: "Environment", label: "Environment" },
  { id: "Quality", label: "Quality" },
  { id: "Delivery", label: "Delivery" },
  { id: "Profit", label: "Profit / Financial" },
  { id: "People", label: "People / HR" },
  { id: "Unassigned", label: "Unassigned" },
];

export default function App() {
  const [query, setQuery] = useState("");
  const [cluster, setCluster] = useState("All");
  const [catalog, setCatalog] = useState(() => {
    const saved = typeof window !== "undefined" && localStorage.getItem("kpi_catalog_sa");
    const base = KPIS && KPIS.length ? KPIS : [];
    return saved ? JSON.parse(saved) : base;
  });
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    localStorage.setItem("kpi_catalog_sa", JSON.stringify(catalog));
  }, [catalog]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return catalog.filter((k) => {
      const clusterOk = cluster === "All" || k.cluster === cluster;
      const text = (`${k.name} ${k.cluster} ${k.definition} ${k.formula} ${k.notes} ${k.perimeter} ${k.outputSource}`).toLowerCase();
      const qOk = !q || text.includes(q);
      return clusterOk && qOk;
    });
  }, [query, cluster, catalog]);

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(catalog, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "kpi-catalog-south-america.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const importJSON = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result);
        if (Array.isArray(data)) {
          setCatalog(data);
        } else {
          alert("Arquivo inválido: deve ser um array de KPIs");
        }
      } catch (err) {
        alert("Erro ao ler JSON");
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="sticky top-0 z-40 backdrop-blur bg-white/80 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <motion.div initial={ rotate: -6 } animate={ rotate: 0 } className="p-2 rounded-2xl bg-slate-900 text-white">
              <Layers size={18} />
            </motion.div>
            <div>
              <h1 className="text-xl font-semibold leading-tight">Manufacturing KPIs — South America</h1>
              <p className="text-slate-500 text-sm -mt-0.5">Catálogo navegável para explicar e padronizar KPIs (2025)</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative w-72">
              <Search className="absolute left-3 top-2.5" size={18} />
              <input
                className="w-full rounded-xl border border-slate-300 pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-400"
                placeholder="Buscar por nome, definição, fórmula…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <div className="relative">
              <select
                className="rounded-xl border border-slate-300 pl-9 pr-3 py-2 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-slate-400"
                value={cluster}
                onChange={(e) => setCluster(e.target.value)}
              >
                <option value="All">Todos os clusters</option>
                {CLUSTERS.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
              <Filter size={18} className="absolute left-2.5 top-2.5 text-slate-500 pointer-events-none" />
            </div>
            <button
              onClick={exportJSON}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-3 py-2 text-sm hover:bg-slate-100"
            >
              <Download size={16} /> Exportar JSON
            </button>
            <label className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-3 py-2 text-sm hover:bg-slate-100 cursor-pointer">
              <Upload size={16} /> Importar JSON
              <input type="file" accept="application/json" className="hidden" onChange={(e) => e.target.files[0] && importJSON(e.target.files[0])} />
            </label>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((kpi, idx) => (
            <motion.button
              key={kpi.name + idx}
              layout
              whileHover={ scale: 1.01 }
              whileTap={ scale: 0.99 }
              onClick={() => setSelected({ ...kpi, index: catalog.findIndex((x) => x.name === kpi.name && x.cluster === kpi.cluster) })}
              className="text-left bg-white rounded-2xl p-4 shadow-sm border border-slate-200 hover:shadow-md"
            >
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-xl bg-slate-100 text-slate-800">
                  <Calculator size={18} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <h2 className="font-semibold leading-tight line-clamp-2">{kpi.name}</h2>
                    <span className="text-xs px-2 py-1 rounded-full bg-slate-900 text-white whitespace-nowrap">{kpi.cluster || '—'}</span>
                  </div>
                  <p className="text-sm text-slate-600 mt-1 line-clamp-3">{kpi.definition}</p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {(kpi.tags || []).slice(0, 3).map((t) => (
                      <span key={t} className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      </main>

      <footer className="max-w-7xl mx-auto px-4 pb-10 text-xs text-slate-500">
        <hr className="my-6" />
        <p>
          Pacote gerado automaticamente a partir do PPT. Revise títulos/campos e ajuste onde necessário.
        </p>
      </footer>

      <AnimatePresence>{selected && (
        <KpiModal
          key={selected.name}
          kpi={selected}
          onClose={() => setSelected(null)}
          onSave={(updated) => {
            const list = [...catalog];
            list[selected.index] = { ...updated };
            setCatalog(list);
            setSelected(null);
          }}
          onDelete={() => {
            const list = catalog.filter((_, i) => i !== selected.index);
            setCatalog(list);
            setSelected(null);
          }}
          onDuplicate={() => {
            const list = [...catalog];
            list.splice(selected.index + 1, 0, { ...selected, name: selected.name + " (copy)" });
            setCatalog(list);
          }}
        />
      )}</AnimatePresence>
    </div>
  );
}

function KpiModal({ kpi, onClose, onSave, onDelete, onDuplicate }) {
  const [draft, setDraft] = React.useState(kpi);
  const [isEditing, setIsEditing] = React.useState(false);

  React.useEffect(() => setDraft(kpi), [kpi]);

  const Field = ({ label, prop, textarea }) => (
    <div>
      <label className="text-xs text-slate-500">{label}</label>
      {textarea ? (
        <textarea
          className="w-full mt-1 rounded-xl border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-400"
          rows={3}
          value={draft[prop] || ""}
          onChange={(e) => setDraft({ ...draft, [prop]: e.target.value })}
          readOnly={!isEditing}
        />
      ) : (
        <input
          className="w-full mt-1 rounded-xl border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-400"
          value={draft[prop] || ""}
          onChange={(e) => setDraft({ ...draft, [prop]: e.target.value })}
          readOnly={!isEditing}
        />
      )}
    </div>
  );

  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center"
      initial={ opacity: 0 }
      animate={ opacity: 1 }
      exit={ opacity: 0 }
    >
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <motion.div
        className="relative z-10 bg-white w-full max-w-3xl rounded-3xl shadow-xl border border-slate-200"
        initial={ y: 30, scale: 0.98, opacity: 0 }
        animate={ y: 0, scale: 1, opacity: 1 }
        exit={ y: 30, scale: 0.98, opacity: 0 }
      >
        <div className="p-5 border-b border-slate-200 flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-slate-900 text-white"><Info size={18} /></div>
            <div>
              {isEditing ? (
                <input
                  className="font-semibold text-lg leading-tight w-full focus:outline-none"
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                />
              ) : (
                <h3 className="font-semibold text-lg leading-tight">{draft.name}</h3>
              )}
              <p className="text-slate-500 text-sm">{draft.cluster}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-slate-100"><X /></button>
        </div>

        <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-4">
          <Field label="Cluster" prop="cluster" />
          <Field label="Tags (separadas por vírgula)" prop="tags" />
          <Field label="Definição" prop="definition" textarea />
          <Field label="Fórmula / Algoritmo" prop="formula" textarea />
          <Field label="Unidade de medida" prop="measureUnit" />
          <Field label="Regra de avaliação" prop="evaluationRule" />
          <Field label="Frequência de medição" prop="frequency" />
          <Field label="Fonte / Output Source" prop="outputSource" />
          <Field label="Perímetro" prop="perimeter" textarea />
          <Field label="Notas" prop="notes" textarea />
          <Field label="Direção de melhoria" prop="improvementDirection" />
        </div>

        <div className="p-5 border-t border-slate-200 flex flex-wrap gap-2 justify-between">
          <div className="flex gap-2">
            {!isEditing ? (
              <button onClick={() => setIsEditing(true)} className="px-3 py-2 text-sm rounded-xl bg-slate-900 text-white">Editar</button>
            ) : (
              <>
                <button onClick={() => setIsEditing(false)} className="px-3 py-2 text-sm rounded-xl border border-slate-300">Cancelar</button>
                <button onClick={() => onSave({ ...draft, tags: normalizeTags(draft.tags) })} className="px-3 py-2 text-sm rounded-xl bg-green-600 text-white">Salvar</button>
              </>
            )}
          </div>
          <div className="flex gap-2">
            <button onClick={onDuplicate} className="px-3 py-2 text-sm rounded-xl border border-slate-300">Duplicar</button>
            <button onClick={onDelete} className="px-3 py-2 text-sm rounded-xl border border-red-300 text-red-700">Excluir</button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function normalizeTags(tags) {
  if (!tags) return [];
  if (Array.isArray(tags)) return tags;
  return String(tags)
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}
